<h1>Crea Tu Outfit - Proyecto CoderHouse</h1> 
<p> Este sitio es sobre moda creado para el curso de desarrollo web</p> 
<h2> Tecnologias usadas </h2>
<ul> 
<li>Html5</li>
<li>CSS3</li>
<li> Bootstrap </li>
<li> SASS </li>
</ul>